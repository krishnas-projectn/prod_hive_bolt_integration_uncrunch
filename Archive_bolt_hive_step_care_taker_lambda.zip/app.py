import json
import multiprocessing
import bolt
import os
import boto3

"""
{'version': '0', 'id': '069dbf78-293f-68bb-d0ff-c79520789fa6', 'detail-type': 'EMR Step Status Change', 'source': 'aws.emr', 'account': '809541265033', 'time': '2021-07-08T22:47:57Z', 'region': 'us-east-2', 'resources': [], 'detail': {'severity': 'INFO', 'actionOnFailure': 'CONTINUE', 'stepId': 's-4GHA2UIX7XM6', 'name': 'Hive program', 'clusterId': 'j-S8SUY3JIBZFM', 'state': 'COMPLETED', 'message': 'Step s-4GHA2UIX7XM6 (Hive program) in Amazon EMR cluster j-S8SUY3JIBZFM (hive-cluster-bolt) completed execution at 2021-07-08 22:47 UTC. The step started running at 2021-07-08 22:41 UTC and took 5 minutes to complete.'}}
"""


def uncrunch_process_method(obj, copy_source, bucket_name, return_uncrunch_status):
    """
    Uncrunch process for the parallel execution
    :param client_bolt:
    :param obj:
    :param copy_source:
    :param bucket_name:
    :param return_uncrunch_status:
    """
    os.environ["BOLT_URL"] = os.environ["BOLT_API_URL"]
    client_bolt = bolt.client('s3')
    print('## INSIDE PROCESS')
    print(obj)
    response = None
    try:
        if "csv" in obj['Key'] or "json" in obj['Key'] or "parquet" in obj['Key']:
            print('## UNCRUNCH OBJECT CSV JSON PARQUET')
            print(obj['Key'])
            response = client_bolt.copy_object(
                Bucket=bucket_name,
                CopySource=copy_source,
                Key=obj["Key"],
                Metadata={
                    'bolt-uncrunch': 'true'
                }
            )
        print('## UNCRUNCH RESPONSE FROM BOLT')
        print(response)

    except Exception as e:
        if "ErrGetObjFromSource" in str(e):
            print('##OBJECT EXISTS IN SOURCE BUCKET')
            print(obj['Key'])
        # Append the return status if it failed
        print('##UNCRUNCH ERROR')
        print(str(e))
        return_uncrunch_status.append(False)


def lambda_handler(event, context):
    # Reading the Alert from the Cloud Watch Rules for Hive EMR Steps
    print("Checkpoint:1 Reading the Hive Alert Event", event, type(event))
    print("Checkpoint:2 Getting the Payload Cluster ID and Step id", event["detail"]["clusterId"],
          event["detail"]["stepId"])
    print("Checkpoint:2.5 Getting the environment variables", os.environ["BOLT_STAGE_BUCKET"], os.environ["BOLT_API_URL"] )
    emr_cluster_id = event["detail"]["clusterId"]
    emr_step_id = event["detail"]["stepId"]
    step_name = event["detail"]["name"]
    client_emr = boto3.client('emr')
    # Using the EMR Describe Step API to get the Input information
    response_emr = client_emr.describe_step(
        ClusterId=emr_cluster_id,
        StepId=emr_step_id)

    # Cancel the step if and only if it not created by Bolt
    if "PROJECTN-BOLT" in step_name:
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "This step has been run by Bolt, so Bolt is igorning this step",
            })
        }
    else:
        response_cancel = client_emr.cancel_steps(
            ClusterId=emr_cluster_id,
            StepIds=[
                emr_step_id,
            ]
        )
        print("0 Canceled the step", response_cancel)
    # Parse arguments to get the Input location and send it to Bolt for hydration
    print("Args with INPUT location:", response_emr["Step"]["Config"]["Args"])
    args_list = response_emr["Step"]["Config"]["Args"]
    #print("FINAL ENV VARIABLES", os.environ['BOLT_STAGE_BUCKET'], os.environ['BOLT_API_URL'])

    # Parse the source bucket and prefix information
    hive_source_bucket = None
    hive_source_key = None
    for input_location in args_list:
        if "INPUT" in input_location:
            # INPUT format 'INPUT=s3://hive-bolt-int/input/' 2nd will be bucket name
            hive_source_bucket = input_location.split("/")[2]
            hive_source_key = "/".join(input_location.split("/")[3:])
            print("Verify the Source Bucket and Source Key", hive_source_key, hive_source_bucket)

    # Talk to the Bolt to hydrate the INPUT location in the source bucket
    # Getting the Bolt S3 client...
    os.environ["BOLT_URL"] = os.environ["BOLT_API_URL"]
    client_s3_bolt = bolt.client('s3')
    contents = None
    print('## MULTI-PROCESSING VARIABLES')
    uncrunch_process_list = []
    uncrunch_manager = multiprocessing.Manager()
    return_uncrunch_status = uncrunch_manager.list()
    try:
        print("Checkpoint:4 Copying crunched data from the source bucket using Bolt client", hive_source_bucket,
              hive_source_key, client_s3_bolt)
        contents = client_s3_bolt.list_objects_v2(Bucket=hive_source_bucket,
                                                  Prefix=hive_source_key,
                                                  MaxKeys=1000)["Contents"]
        print("Checkpoint:5 Got the contents using the Bolt client from the source bucket", len(contents))
    except Exception as e:
        print("Error while getting contents from Bolt client", e.__doc__)

    # Copying the data to the staging bucket from the source bucket...
    for idx, obj in enumerate(contents):
        copy_source = f"/{hive_source_bucket}/{obj['Key']}"
        print("Copying From Source bucket using Bolt client", copy_source)
        uncrunch_process = multiprocessing.Process(target=uncrunch_process_method,
                                                   args=[obj, copy_source, hive_source_bucket, return_uncrunch_status])
        uncrunch_process.start()
        uncrunch_process_list.append(uncrunch_process)

    # waiting for the processes to complete
    for process in uncrunch_process_list:
        process.join()

    # Rerun the EMR Step using the Step ID information
    step_by_bolt = {"Name": step_name + "-PROJECTN-BOLT",
                    'ActionOnFailure': 'CONTINUE',
                    'HadoopJarStep': {
                        'Jar': 'command-runner.jar',
                        'Args': args_list
                    }
                    }
    print("Forming the step: BOLT", step_by_bolt)
    bolt_action = client_emr.add_job_flow_steps(JobFlowId=emr_cluster_id, Steps=[step_by_bolt])
    print("Running the New Step created by BOLT", bolt_action)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Data files are loaded Successfully",
        }),
    }
